# adminendpoints/__init__.py
# Paquete de endpoints del Panel Admin CGPVP
