# EndpointInstructores.py
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List
from Conexiónsql import get_connection

app = FastAPI()

# ---------------------------
# Función genérica para ejecutar SP
# ---------------------------
def ejecutar_sp(sp_nombre: str, params: tuple):
    """Ejecuta un SP con parámetros y devuelve resultados como lista de diccionarios."""
    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(f"EXEC {sp_nombre} " + ",".join(["?"]*len(params)), params)
            
            if cursor.description:  # SP devuelve filas
                columns = [col[0] for col in cursor.description]
                rows = cursor.fetchall()
                resultados = [dict(zip(columns, row)) for row in rows]
                return resultados
            else:  # SP solo devuelve status / mensaje
                return [{"status": "SUCCESS", "mensaje": "SP ejecutado correctamente"}]

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# =============================================
# SP1: REGISTRAR NUEVO INSTRUCTOR
# =============================================
class InstructorCrear(BaseModel):
    nombre_completo: str
    especialidad: str
    rango: str | None = None
    experiencia_anios: int = 0
    certificaciones: str | None = None
    email: str | None = None
    telefono: str | None = None
    foto: str | None = None
    bio: str | None = None
    admin_id: int

@app.post("/instructores")
def registrar_instructor(instructor: InstructorCrear):
    resultados = ejecutar_sp("SP_REGISTRAR_INSTRUCTOR", (
        instructor.nombre_completo,
        instructor.especialidad,
        instructor.rango,
        instructor.experiencia_anios,
        instructor.certificaciones,
        instructor.email,
        instructor.telefono,
        instructor.foto,
        instructor.bio,
        instructor.admin_id
    ))
    return resultados[0]

# =============================================
# SP2: ACTUALIZAR INSTRUCTOR
# =============================================
class InstructorActualizar(BaseModel):
    id_instructor: int
    nombre_completo: str
    especialidad: str
    rango: str | None = None
    experiencia_anios: int
    certificaciones: str | None = None
    email: str | None = None
    telefono: str | None = None
    foto: str | None = None
    bio: str | None = None
    estado: str
    admin_id: int

@app.put("/instructores")
def actualizar_instructor(instr: InstructorActualizar):
    resultados = ejecutar_sp("SP_ACTUALIZAR_INSTRUCTOR", (
        instr.id_instructor,
        instr.nombre_completo,
        instr.especialidad,
        instr.rango,
        instr.experiencia_anios,
        instr.certificaciones,
        instr.email,
        instr.telefono,
        instr.foto,
        instr.bio,
        instr.estado,
        instr.admin_id
    ))
    return resultados[0]

# =============================================
# SP3: LISTAR INSTRUCTORES
# =============================================
class FiltroInstructores(BaseModel):
    especialidad: str | None = None
    estado: str = "Activo"
    busqueda: str | None = None
    ordenar_por: str = "nombre"

@app.post("/instructores/listar")
def listar_instructores(filtro: FiltroInstructores):
    resultados = ejecutar_sp("SP_LISTAR_INSTRUCTORES", (
        filtro.especialidad,
        filtro.estado,
        filtro.busqueda,
        filtro.ordenar_por
    ))
    return {"status": "SUCCESS", "resultados": resultados}

# =============================================
# SP4: OBTENER INSTRUCTOR POR ID
# =============================================
class InstructorID(BaseModel):
    id_instructor: int

@app.post("/instructores/perfil")
def obtener_instructor_por_id(instr: InstructorID):
    resultados = ejecutar_sp("SP_OBTENER_INSTRUCTOR_POR_ID", (instr.id_instructor,))
    return {"status": "SUCCESS", "resultados": resultados}

# =============================================
# SP5: LISTAR INSTRUCTORES POR ESPECIALIDAD
# =============================================
@app.get("/instructores/por_especialidad")
def contar_instructores_por_especialidad():
    resultados = ejecutar_sp("SP_CONTAR_INSTRUCTORES_POR_ESPECIALIDAD", ())
    return {"status": "SUCCESS", "resultados": resultados}

# =============================================
# SP6: CAMBIAR ESTADO DE INSTRUCTOR
# =============================================
class CambioEstado(BaseModel):
    id_instructor: int
    nuevo_estado: str
    admin_id: int

@app.put("/instructores/estado")
def cambiar_estado_instructor(data: CambioEstado):
    resultados = ejecutar_sp("SP_CAMBIAR_ESTADO_INSTRUCTOR", (
        data.id_instructor,
        data.nuevo_estado,
        data.admin_id
    ))
    return resultados[0]

# =============================================
# SP7: ELIMINAR INSTRUCTOR (SOFT DELETE)
# =============================================
class EliminarInstructor(BaseModel):
    id_instructor: int
    admin_id: int

@app.delete("/instructores")
def eliminar_instructor(data: EliminarInstructor):
    resultados = ejecutar_sp("SP_ELIMINAR_INSTRUCTOR", (
        data.id_instructor,
        data.admin_id
    ))
    return resultados[0]

# =============================================
# SP8: BUSCAR INSTRUCTORES (AUTOCOMPLETADO)
# =============================================
class BusquedaInstructores(BaseModel):
    termino_busqueda: str

@app.post("/instructores/buscar")
def buscar_instructores(data: BusquedaInstructores):
    resultados = ejecutar_sp("SP_BUSCAR_INSTRUCTORES", (data.termino_busqueda,))
    return {"status": "SUCCESS", "resultados": resultados}

# =============================================
# SP9: OBTENER INSTRUCTORES DESTACADOS
# =============================================
@app.get("/instructores/destacado")
def obtener_instructor_destacado():
    resultados = ejecutar_sp("SP_OBTENER_INSTRUCTOR_DESTACADO", ())
    return {"status": "SUCCESS", "resultados": resultados}

# =============================================
# SP10: ESTADÍSTICAS GENERALES DE INSTRUCTORES
# =============================================
@app.get("/instructores/estadisticas")
def estadisticas_instructores():
    resultados = ejecutar_sp("SP_ESTADISTICAS_INSTRUCTORES", ())
    return {"status": "SUCCESS", "resultados": resultados}

# =============================================
# SP11: ASIGNAR INSTRUCTOR A CURSO
# =============================================
class AsignacionCurso(BaseModel):
    id_curso: int
    id_instructor: int
    admin_id: int

@app.post("/instructores/asignar_curso")
def asignar_instructor_curso(asignacion: AsignacionCurso):
    resultados = ejecutar_sp("SP_ASIGNAR_INSTRUCTOR_A_CURSO", (
        asignacion.id_curso,
        asignacion.id_instructor,
        asignacion.admin_id
    ))
    return resultados[0]

# =============================================
# SP12: ASIGNAR INSTRUCTOR A EVENTO
# =============================================
class AsignacionEvento(BaseModel):
    id_evento: int
    id_instructor: int
    admin_id: int

@app.post("/instructores/asignar_evento")
def asignar_instructor_evento(asignacion: AsignacionEvento):
    resultados = ejecutar_sp("SP_ASIGNAR_INSTRUCTOR_A_EVENTO", (
        asignacion.id_evento,
        asignacion.id_instructor,
        asignacion.admin_id
    ))
    return resultados[0]
